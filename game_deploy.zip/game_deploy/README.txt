INSTRUCTIONS FOR HOSTINGER DEPLOYMENT
=====================================

1. This folder contains your game website ready for deployment.
   - index.html (The main page)
   - style.css  (Visual styles)
   - game.js    (Game logic)

2. To deploy to Hostinger:
   - Open your Hostinger File Manager (usually in public_html).
   - Drag and drop these 3 files (index.html, style.css, game.js) into the public_html folder.
   - That's it! Your website should be live.

Note: If you want to put it in a subfolder (e.g., yoursite.com/game), create a folder named 'game' in public_html and drag these files there.

